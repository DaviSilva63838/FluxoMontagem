## 1. O montador precisa saber o que ele vai colocar em cada caixa
- [[1.1-como-os-dados-dos-kits-chegariam-para-o-montador]]
  - [[1.2-qual-a-melhor-forma-de-separar-e-agrupar-os-dados-pro-montador]]

## 2. Melhor forma logística para o montador conseguir acessar os itens necessários em cada caixa
- [[2.1-aonde-estao-esses-itens]]
- [[2.2-quais-formas-eu-tenho-para-acessar-esses-itens]]
- [[2.3-como-esses-itens-estao-separados]]
- [[2.4-como-o-montador-organizaria-a-coleta-desses-itens]]

## 3. Fluxo de notas fiscais e etiquetas
- [[3.1-como-garantir-que-toda-caixa-tenha-nota-fiscal-e-etiqueta-colada]]
- [[3.2-como-funcionam-essas-etiquetas-e-notas]]

## 4. Fluxo de montagem de caixas
- [[4.1-qual-a-melhor-maneira-de-colocar-os-itens-em-cada-caixa]]
- [[4.2-o-que-e-montar-uma-caixa]]
- [[4.3-o-que-acontece-com-a-caixa-apos-a-montagem]]

## 5. Como os itens estariam dispostos depois que alguém os organizou para o montador usar
- [[5.1-qual-a-melhor-forma-do-montador-pegar-esse-itens]]
- [[5.2-onde-e-como-esses-itens-foram-disponibilizados]]
